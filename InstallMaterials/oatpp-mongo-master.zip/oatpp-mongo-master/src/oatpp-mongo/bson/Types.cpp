/***************************************************************************
 *
 * Project         _____    __   ____   _      _
 *                (  _  )  /__\ (_  _)_| |_  _| |_
 *                 )(_)(  /(__)\  )( (_   _)(_   _)
 *                (_____)(__)(__)(__)  |_|    |_|
 *
 *
 * Copyright 2018-present, Leonid Stryzhevskyi <lganzzzo@gmail.com>
 *                         Benedikt-Alexander Mokroß <bam@icognize.de>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ***************************************************************************/

#include "Types.hpp"

namespace oatpp { namespace mongo { namespace bson {

namespace __class {

  const ClassId InlineDocument::CLASS_ID("oatpp::mongo::InlineDocument");
  const ClassId InlineArray::CLASS_ID("oatpp::mongo::InlineArray");
  const ClassId ObjectId::CLASS_ID("oatpp::mongo::ObjectId");
  const ClassId DateTime::CLASS_ID("oatpp::mongo::DateTime");

}

}}}
